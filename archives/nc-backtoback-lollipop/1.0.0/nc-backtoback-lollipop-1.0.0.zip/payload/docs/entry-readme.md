# NC背靠背棒棒图（LHSC）

## Purpose
复刻专辑文《nature communications同款：独特的背靠背棒棒图绘制》的 LHSC 面板。

## Inputs
- `data/41467_2025_60900_MOESM13_ESM.xlsx` sheet Fig5

## Methods
左右 `geom_col` + `geom_point(size=EC_score)`；左 van Galen 反转 x，右 Pei。

## Software
- 文献：DOI 10.1038/s41467-025-60900-4

## Commands
```text
pixi run Rscript drafts/nc-backtoback-lollipop/code/organized.R
```

## Limitations
只复刻 LHSC。确认前不发布。
