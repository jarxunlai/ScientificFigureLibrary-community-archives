# KEGG变体条形图（柱内通路名）

## Purpose
复刻专辑文《同款高分杂志的富集分析结果展示：变体条形图绘制》终图 ggplot。

## Inputs
- `data/kegg_top15.csv` — 15 条通路名对齐微信终图

## Methods
作者 `geom_bar` + `geom_text` 柱内标签；前 7 条白字、后 8 条黑字；黄到深红渐变。

## Commands
```text
pixi run Rscript drafts/kegg-variant-inside-label-bar/code/organized.R
```

## Limitations
合成 p.adjust。确认前不发布。
