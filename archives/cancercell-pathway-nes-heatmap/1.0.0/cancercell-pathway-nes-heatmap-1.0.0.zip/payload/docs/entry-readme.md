# Cancer Cell通路NES热图

## Purpose
按专辑文作者的 **ComplexHeatmap** 代码复刻樊嘉团队 Cancer Cell 通路 NES 热图。

## Inputs
- `data/pathway_nes.csv` — 通路名单与 InputSig 星号行号来自原文；NES 为合成值（mmc6 未提供）

## Methods
原文 `Heatmap()`：`left_annotation` 分类色条、`top_annotation` 亚型、`column_split` A–D、`row_split` Category、白边、格子内 `*`。画布加宽到 11 in，避免图例压住通路名。

## Software
- ComplexHeatmap 2.26.1（Bioconductor）；circlize 0.4.18；ggsci 5.2.0

## Commands
```text
pixi run Rscript drafts/cancercell-pathway-nes-heatmap/code/organized.R
```

## Limitations
无 mmc6 原表。确认前不发布。
