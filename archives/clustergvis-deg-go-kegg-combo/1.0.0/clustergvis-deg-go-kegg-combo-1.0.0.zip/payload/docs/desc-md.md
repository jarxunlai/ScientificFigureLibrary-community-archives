# 差异基因聚类热图加GO和KEGG注释

复刻微信文章中的 ClusterGVis 组合图：把显著差异基因按表达模式分成 C3/C1/C4/C2，再把每个 cluster 的 GO 与 KEGG 放在同一张图右侧。

文章的一句话总结是：KRAS_G12D 转录组变化分成两大方向——IFN/ISG、抗病毒样反应、先天免疫和抗原呈递上调；ECM、细胞黏附、Wnt/结构发育相关程序下降。本条目只复刻这个**版式**，不证明该生物学结论。

## Visual structure

从左到右：

1. 行标题 C3 / C1 / C4 / C2。
2. 每个 cluster 一个小折线框，红线为该 cluster 基因在 14 个样本上的中位 Z-score，框内标注 `Gene size`。
3. 灰色梯形把折线框连到热图块（ComplexHeatmap `anno_link`）。
4. 斜体基因标记在热图左侧，颜色跟随 cluster 色条。
5. 热图：行 = 基因，列 = 14 个样本，按 WT_control | KRAS_G12D 切开；蓝-白-红 Z-score，−2 到 2。
6. 热图右侧窄色条写 `Num: n`。
7. 再右两列文本盒：GO、KEGG，`anno_block` 风格。
8. 最右图例：sample 与 Z-score。

## Data requirements

- 宽表：基因 × 样本的行标准化 Z-score，另有 cluster 列。
- GO/KEGG 长表：`id`（C1–C4）与 `term`。
- 更换真实数据时，cluster 大小、标记基因和富集条目都要跟着换，不能沿用合成轮廓。

## Recommended use

需要把“谁一起变”和“这些基因干什么”画在同一 panel 时使用。适合 RNA-seq DEG 下游，不适合单基因火山图。

## Limitations

- 合成数据，不是 GEO 原始 counts。
- 未调用 ClusterGVis / clusterProfiler / org.Mm.eg.db。
- 样本名 `E262_*` 来自截图判读，存在不确定性。
