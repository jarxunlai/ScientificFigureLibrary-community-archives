# 单细胞marker气泡图加突出框

## Purpose
复刻专辑文《顶刊杂志同款单细胞marker基因气泡图：加个框框突出marker》。

## Inputs
- `data/dotplot_dt.csv` — 作者 23 个基因 × cluster 0–11

## Methods
`geom_point(shape=21)` + 三个 `annotate("rect")`，框坐标与原文一致。

## Commands
```text
pixi run Rscript drafts/sc-marker-dotplot-highlight-boxes/code/organized.R
```

## Limitations
合成表达。确认前不发布。
