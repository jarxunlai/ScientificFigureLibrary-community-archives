# Nature同款空转生态位堆积柱

## Purpose
复刻专辑文《绘制 Nature 同款空转细胞生态位堆积柱状图》。

## Inputs
- `data/niche_proportions.csv` — 按期刊 27 个样本名合成的 niche 比例

## Methods
`geom_bar(position_fill(reverse=TRUE))`；配色按作者 9 色。

## Commands
```text
pixi run Rscript drafts/nature-spatial-niche-stacked-bar/code/organized.R
```

## Limitations
合成比例。确认前不发布。
