# Nature风格四分组PCA

## Purpose
复刻专辑文《Nature顶刊同款高颜值PCA分析图》的 ggplot 美化终图。

## Inputs
- `data/pca_df.csv` — 合成 PC1/PC2 与分组

## Methods
`stat_ellipse` + `geom_point(shape=21)` + `geom_text_repel`；配色 healthy/NAFLD/NASH/obese 按原文。

## Commands
```text
pixi run Rscript drafts/nature-metabolome-style-pca/code/organized.R
```

## Limitations
合成坐标。确认前不发布。
