# KEGG变体条形图（前三白字）

微信文 ggplot 第二版。数据同终图。

```text
pixi run Rscript drafts/kegg-variant-bw-text-classic/code/organized.R
```
