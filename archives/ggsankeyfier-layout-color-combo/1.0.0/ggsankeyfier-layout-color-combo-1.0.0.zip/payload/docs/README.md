# Portable multi-stage Sankey layout

This clean-room example visualizes nine synthetic flows across input, layout, and output stages.
All labels, values, node positions, and colors were authored for this public template. The
renderer uses its own portable raster primitives and does not require fonts or extension packages.
No book, paper, website, screenshot, private cache, or pre-existing layout is included.

## Re-render

Run the fixed entrypoint with `--input-dir payload/data --output preview.png`.
The renderer uses only base R and writes a deterministic indexed PNG.
