# KEGG变体条形图（蓝黄红柱内标签）

微信文《变体条形图绘制》ggplot 第一版。数据同 `kegg-variant-inside-label-bar`。

```text
pixi run Rscript drafts/kegg-variant-blue-inside-label/code/organized.R
```
