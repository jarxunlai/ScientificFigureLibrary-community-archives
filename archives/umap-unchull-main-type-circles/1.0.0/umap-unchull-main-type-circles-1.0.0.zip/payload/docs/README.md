# Embedding clusters with major-type circles

This clean-room example contains 360 abstract two-dimensional points generated with seed 604003.
Labels are limited to Major A/B/C and Cluster 1/2/3. Circle centers and radii are calculated
from the bundled coordinates; no label anchor or outline is copied from a paper or tutorial.
The input is synthetic and contains no GEO, patient, experimental, or private data.

## Re-render

Run the fixed entrypoint with `--input-dir payload/data --output preview.png`.
The renderer uses only base R and writes a deterministic indexed PNG.
