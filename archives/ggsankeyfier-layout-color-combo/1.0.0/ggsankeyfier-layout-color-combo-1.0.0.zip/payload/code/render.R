args <- commandArgs(trailingOnly = TRUE)

read_flag <- function(name) {
  hit <- match(name, args)
  if (is.na(hit) || hit == length(args)) stop(paste("missing", name), call. = FALSE)
  args[[hit + 1L]]
}

input_dir <- normalizePath(read_flag("--input-dir"), mustWork = TRUE)
output_file <- read_flag("--output")
if (file.exists(output_file)) stop("output must not exist", call. = FALSE)
dir.create(dirname(output_file), recursive = TRUE, showWarnings = FALSE)

TEMPLATE_KIND <- "sankey"
W <- 900L
H <- 600L

# This indexed palette and the rasterizer below are intentionally device- and
# font-independent. The same input bytes produce the same RGBA pixels on every
# base R 4.4+ platform used by the reviewed renderer.
PALETTE <- rbind(
  c(247, 249, 252), c(22, 32, 42), c(99, 112, 131), c(220, 227, 234),
  c(255, 255, 255), c(42, 157, 143), c(231, 111, 81), c(233, 196, 106),
  c(58, 134, 255), c(131, 56, 236), c(255, 112, 166), c(215, 241, 236),
  c(249, 223, 216), c(220, 234, 255), c(234, 223, 252), c(29, 91, 82),
  c(164, 74, 55), c(160, 126, 43), c(36, 86, 168), c(81, 42, 145)
)

canvas <- matrix(as.raw(0L), nrow = H, ncol = W)

clip_range <- function(a, lo, hi) seq.int(max(lo, as.integer(a[[1L]])), min(hi, as.integer(a[[2L]])))

fill_rect <- function(x1, y1, x2, y2, colour) {
  xs <- clip_range(c(x1, x2), 1L, W); ys <- clip_range(c(y1, y2), 1L, H)
  if (length(xs) && length(ys)) canvas[ys, xs] <<- as.raw(colour)
}

draw_circle <- function(cx, cy, radius, colour) {
  cx <- as.integer(round(cx)); cy <- as.integer(round(cy)); radius <- as.integer(max(0, round(radius)))
  for (yy in seq.int(max(1L, cy - radius), min(H, cy + radius))) {
    half <- floor(sqrt(max(0, radius * radius - (yy - cy) * (yy - cy))))
    xs <- seq.int(max(1L, cx - half), min(W, cx + half))
    if (length(xs)) canvas[yy, xs] <<- as.raw(colour)
  }
}

draw_ring <- function(cx, cy, radius, width, colour, inner_colour = 0L) {
  draw_circle(cx, cy, radius, colour)
  draw_circle(cx, cy, max(0, radius - width), inner_colour)
}

draw_line <- function(x1, y1, x2, y2, width, colour) {
  n <- as.integer(max(abs(x2 - x1), abs(y2 - y1), 1))
  xs <- seq(x1, x2, length.out = n + 1L); ys <- seq(y1, y2, length.out = n + 1L)
  for (i in seq_along(xs)) draw_circle(xs[[i]], ys[[i]], width / 2, colour)
}

draw_curve <- function(x1, y1, x2, y2, width, colour) {
  t <- seq(0, 1, length.out = 90L)
  c1x <- x1 + (x2 - x1) * 0.42; c2x <- x2 - (x2 - x1) * 0.42
  xs <- (1 - t)^3 * x1 + 3 * (1 - t)^2 * t * c1x + 3 * (1 - t) * t^2 * c2x + t^3 * x2
  ys <- (1 - t)^3 * y1 + 3 * (1 - t)^2 * t * y1 + 3 * (1 - t) * t^2 * y2 + t^3 * y2
  for (i in seq_along(xs)) draw_circle(xs[[i]], ys[[i]], width / 2, colour)
}

FONT <- c(
  A="01110/10001/10001/11111/10001/10001/10001", B="11110/10001/10001/11110/10001/10001/11110",
  C="01111/10000/10000/10000/10000/10000/01111", D="11110/10001/10001/10001/10001/10001/11110",
  E="11111/10000/10000/11110/10000/10000/11111", F="11111/10000/10000/11110/10000/10000/10000",
  G="01111/10000/10000/10111/10001/10001/01111", H="10001/10001/10001/11111/10001/10001/10001",
  I="11111/00100/00100/00100/00100/00100/11111", J="00111/00010/00010/00010/10010/10010/01100",
  K="10001/10010/10100/11000/10100/10010/10001", L="10000/10000/10000/10000/10000/10000/11111",
  M="10001/11011/10101/10101/10001/10001/10001", N="10001/11001/10101/10011/10001/10001/10001",
  O="01110/10001/10001/10001/10001/10001/01110", P="11110/10001/10001/11110/10000/10000/10000",
  Q="01110/10001/10001/10001/10101/10010/01101", R="11110/10001/10001/11110/10100/10010/10001",
  S="01111/10000/10000/01110/00001/00001/11110", T="11111/00100/00100/00100/00100/00100/00100",
  U="10001/10001/10001/10001/10001/10001/01110", V="10001/10001/10001/10001/10001/01010/00100",
  W="10001/10001/10001/10101/10101/10101/01010", X="10001/10001/01010/00100/01010/10001/10001",
  Y="10001/10001/01010/00100/00100/00100/00100", Z="11111/00001/00010/00100/01000/10000/11111",
  `0`="01110/10001/10011/10101/11001/10001/01110", `1`="00100/01100/00100/00100/00100/00100/01110",
  `2`="01110/10001/00001/00010/00100/01000/11111", `3`="11110/00001/00001/01110/00001/00001/11110",
  `4`="00010/00110/01010/10010/11111/00010/00010", `5`="11111/10000/10000/11110/00001/00001/11110",
  `6`="01110/10000/10000/11110/10001/10001/01110", `7`="11111/00001/00010/00100/01000/01000/01000",
  `8`="01110/10001/10001/01110/10001/10001/01110", `9`="01110/10001/10001/01111/00001/00001/01110",
  `-`="00000/00000/00000/11111/00000/00000/00000", `.`="00000/00000/00000/00000/00000/00110/00110",
  `:`="00000/00110/00110/00000/00110/00110/00000", `/`="00001/00010/00010/00100/01000/01000/10000",
  `+`="00000/00100/00100/11111/00100/00100/00000", ` `="00000/00000/00000/00000/00000/00000/00000"
)

text_width <- function(label, scale = 2L) nchar(label) * 6L * scale - scale

draw_text <- function(x, y, label, scale = 2L, colour = 1L, align = "left") {
  label <- toupper(label)
  if (align == "center") x <- x - text_width(label, scale) / 2
  if (align == "right") x <- x - text_width(label, scale)
  cursor <- as.integer(round(x))
  for (ch in strsplit(label, "", fixed = TRUE)[[1L]]) {
    pattern <- FONT[[ch]]
    if (is.null(pattern)) pattern <- "11111/10001/00110/00100/00000/00100/00000"
    rows <- strsplit(pattern, "/", fixed = TRUE)[[1L]]
    for (rr in seq_along(rows)) {
      bits <- strsplit(rows[[rr]], "", fixed = TRUE)[[1L]]
      for (cc in seq_along(bits)) if (bits[[cc]] == "1") {
        fill_rect(cursor + (cc - 1L) * scale, y + (rr - 1L) * scale,
                  cursor + cc * scale - 1L, y + rr * scale - 1L, colour)
      }
    }
    cursor <- cursor + 6L * scale
  }
}

draw_header <- function(title, subtitle) {
  draw_text(45, 35, title, 3L, 1L)
  draw_text(46, 66, subtitle, 1L, 2L)
  fill_rect(45, 91, 855, 93, 3L)
}

render_enrichment <- function() {
  d <- read.csv(file.path(input_dir, "enrichment.csv"), stringsAsFactors = FALSE, check.names = FALSE)
  needed <- c("cluster", "pathway", "score", "gene_count", "genes")
  if (!identical(names(d), needed) || nrow(d) != 8L || any(!is.finite(d$score)) || any(d$score <= 0)) stop("invalid enrichment input", call. = FALSE)
  draw_header("ENRICHMENT OVERVIEW", "SYNTHETIC LONG TABLE  /  SCORE AND GENE COUNT")
  clusters <- c("Cluster A", "Cluster B")
  panel_x <- c(45L, 465L)
  colours <- c(5L, 8L)
  pale <- c(11L, 13L)
  for (panel in 1:2) {
    x0 <- panel_x[[panel]]; dd <- d[d$cluster == clusters[[panel]], , drop = FALSE]
    fill_rect(x0, 120, x0 + 390, 545, 4L)
    fill_rect(x0, 120, x0 + 390, 163, pale[[panel]])
    draw_text(x0 + 18, 134, clusters[[panel]], 2L, colours[[panel]])
    draw_text(x0 + 320, 139, "SCORE", 1L, 2L, "center")
    for (i in seq_len(nrow(dd))) {
      yy <- 190L + (i - 1L) * 86L
      draw_text(x0 + 18, yy, dd$pathway[[i]], 1L, 1L)
      draw_text(x0 + 18, yy + 19, dd$genes[[i]], 1L, 2L)
      fill_rect(x0 + 176, yy + 4, x0 + 346, yy + 21, 3L)
      bw <- round(170 * dd$score[[i]] / 9)
      fill_rect(x0 + 176, yy + 4, x0 + 176 + bw, yy + 21, colours[[panel]])
      draw_text(x0 + 354, yy + 7, sprintf("%02d", round(dd$score[[i]])), 1L, 1L)
      for (g in seq_len(min(8L, dd$gene_count[[i]] %/% 3L))) draw_circle(x0 + 183 + (g - 1L) * 16L, yy + 43, 5, colours[[panel]])
      draw_text(x0 + 322, yy + 39, paste0("N ", dd$gene_count[[i]]), 1L, 2L, "right")
      fill_rect(x0 + 18, yy + 66, x0 + 372, yy + 67, 3L)
    }
  }
  draw_text(450, 571, "CLEAN-ROOM SYNTHETIC EXAMPLE", 1L, 2L, "center")
}

render_sankey <- function() {
  d <- read.csv(file.path(input_dir, "flows.csv"), stringsAsFactors = FALSE, check.names = FALSE)
  needed <- c("source", "middle", "target", "value")
  if (!identical(names(d), needed) || nrow(d) != 9L || any(!is.finite(d$value)) || any(d$value <= 0)) stop("invalid flow input", call. = FALSE)
  draw_header("MULTI-STAGE SANKEY", "SYNTHETIC FLOWS  /  LAYOUT AND COLOR COMBINATION")
  left <- c("Input A" = 185, "Input B" = 315, "Input C" = 445)
  middle <- c("Layout 1" = 175, "Layout 2" = 315, "Layout 3" = 455)
  right <- c("Output X" = 185, "Output Y" = 315, "Output Z" = 445)
  src_col <- c("Input A" = 11L, "Input B" = 12L, "Input C" = 14L)
  src_dark <- c("Input A" = 5L, "Input B" = 6L, "Input C" = 9L)
  draw_text(110, 122, "INPUT", 1L, 2L, "center")
  draw_text(450, 122, "LAYOUT", 1L, 2L, "center")
  draw_text(790, 122, "OUTPUT", 1L, 2L, "center")
  for (i in order(d$value, decreasing = TRUE)) {
    width <- 7 + d$value[[i]] * 1.8
    draw_curve(145, left[[d$source[[i]]]], 415, middle[[d$middle[[i]]]], width, src_col[[d$source[[i]]]])
    draw_curve(485, middle[[d$middle[[i]]]], 755, right[[d$target[[i]]]], width, src_col[[d$source[[i]]]])
  }
  for (nm in names(left)) {
    yy <- left[[nm]]; fill_rect(75, yy - 32, 145, yy + 32, src_dark[[nm]])
    draw_text(110, yy - 7, nm, 1L, 4L, "center")
  }
  mid_col <- c(8L, 7L, 10L)
  for (i in seq_along(middle)) {
    yy <- middle[[i]]; fill_rect(415, yy - 38, 485, yy + 38, mid_col[[i]])
    draw_text(450, yy - 7, names(middle)[[i]], 1L, 1L, "center")
  }
  right_col <- c(18L, 17L, 19L)
  for (i in seq_along(right)) {
    yy <- right[[i]]; fill_rect(755, yy - 32, 825, yy + 32, right_col[[i]])
    draw_text(790, yy - 7, names(right)[[i]], 1L, 4L, "center")
  }
  fill_rect(75, 525, 825, 527, 3L)
  draw_text(450, 550, "THREE STAGES  /  NINE FLOWS  /  TOTAL 100", 1L, 2L, "center")
}

render_umap <- function() {
  d <- read.csv(file.path(input_dir, "embedding.csv"), stringsAsFactors = FALSE, check.names = FALSE)
  needed <- c("major", "cluster", "x", "y")
  if (!identical(names(d), needed) || nrow(d) != 360L || any(!is.finite(d$x)) || any(!is.finite(d$y))) stop("invalid embedding input", call. = FALSE)
  draw_header("ABSTRACT EMBEDDING", "FIXED-SEED SYNTHETIC POINTS  /  DATA-DERIVED CIRCLES")
  fill_rect(65, 120, 835, 535, 4L)
  for (gx in seq(160, 760, by = 150)) fill_rect(gx, 135, gx, 510, 3L)
  for (gy in seq(190, 490, by = 75)) fill_rect(80, gy, 820, gy, 3L)
  sx <- function(x) 100 + (x - min(d$x)) / diff(range(d$x)) * 700
  sy <- function(y) 500 - (y - min(d$y)) / diff(range(d$y)) * 340
  majors <- c("Major A", "Major B", "Major C")
  clusters <- c("Cluster 1", "Cluster 2", "Cluster 3")
  point_col <- c(5L, 6L, 9L); pale <- c(11L, 12L, 14L); dark <- c(15L, 16L, 19L)
  centers <- matrix(0, nrow = 3, ncol = 2)
  radii <- numeric(3)
  for (i in 1:3) {
    dd <- d[d$major == majors[[i]], , drop = FALSE]
    px <- sx(dd$x); py <- sy(dd$y)
    centers[i, ] <- c(mean(px), mean(py))
    radii[[i]] <- min(130, max(sqrt((px - centers[i, 1])^2 + (py - centers[i, 2])^2)) + 19)
    draw_ring(centers[i, 1], centers[i, 2], radii[[i]], 5, pale[[i]], 4L)
  }
  for (i in 1:3) {
    dd <- d[d$cluster == clusters[[i]], , drop = FALSE]
    px <- sx(dd$x); py <- sy(dd$y)
    for (j in seq_along(px)) draw_circle(px[[j]], py[[j]], 3, point_col[[i]])
    draw_circle(centers[i, 1], centers[i, 2], 7, dark[[i]])
    draw_text(centers[i, 1], centers[i, 2] - 29, majors[[i]], 2L, dark[[i]], "center")
    draw_text(centers[i, 1], centers[i, 2] + 16, clusters[[i]], 1L, dark[[i]], "center")
  }
  draw_text(78, 553, "SEED 604003", 1L, 2L)
  draw_text(822, 553, "N 360", 1L, 2L, "right")
}

if (TEMPLATE_KIND == "enrichment") render_enrichment() else if (TEMPLATE_KIND == "sankey") render_sankey() else if (TEMPLATE_KIND == "umap") render_umap() else stop("unknown template kind", call. = FALSE)

u16le <- function(x) as.raw(c(x %% 256L, floor(x / 256L) %% 256L))
u32be <- function(x) {
  value <- as.double(x); if (value < 0) value <- value + 4294967296
  as.raw(c(floor(value / 16777216) %% 256, floor(value / 65536) %% 256, floor(value / 256) %% 256, value %% 256))
}

crc_table <- vapply(0:255, function(i) {
  value <- as.integer(i)
  for (j in 1:8) value <- if (bitwAnd(value, 1L)) bitwXor(bitwShiftR(value, 1L), -306674912L) else bitwShiftR(value, 1L)
  value
}, integer(1L))

crc32 <- function(bytes) {
  value <- -1L
  for (byte in as.integer(bytes)) {
    index <- bitwAnd(bitwXor(value, byte), 255L) + 1L
    value <- bitwXor(bitwShiftR(value, 8L), crc_table[[index]])
  }
  bitwNot(value)
}

adler32 <- function(bytes) {
  a <- 1; b <- 0
  values <- as.integer(bytes)
  for (start in seq.int(1L, length(values), by = 5552L)) {
    part <- values[start:min(length(values), start + 5551L)]
    for (value in part) { a <- (a + value) %% 65521; b <- (b + a) %% 65521 }
  }
  b * 65536 + a
}

zlib_store <- function(bytes) {
  output <- as.raw(c(0x78, 0x01)); position <- 1L; total <- length(bytes)
  while (position <= total) {
    size <- min(65535L, total - position + 1L); final <- as.integer(position + size - 1L == total)
    output <- c(output, as.raw(final), u16le(size), u16le(bitwAnd(bitwNot(size), 65535L)), bytes[position:(position + size - 1L)])
    position <- position + size
  }
  c(output, u32be(adler32(bytes)))
}

png_chunk <- function(kind, payload = raw()) {
  type <- charToRaw(kind); c(u32be(length(payload)), type, payload, u32be(crc32(c(type, payload))))
}

scanlines <- raw(H * (W + 1L))
for (yy in seq_len(H)) {
  offset <- (yy - 1L) * (W + 1L)
  scanlines[offset + 1L] <- as.raw(0L)
  scanlines[offset + 1L + seq_len(W)] <- canvas[yy, ]
}

ihdr <- c(u32be(W), u32be(H), as.raw(c(8, 3, 0, 0, 0)))
plte <- as.raw(as.vector(t(PALETTE)))
png <- c(as.raw(c(137, 80, 78, 71, 13, 10, 26, 10)), png_chunk("IHDR", ihdr), png_chunk("PLTE", plte), png_chunk("IDAT", zlib_store(scanlines)), png_chunk("IEND"))
connection <- file(output_file, open = "wb")
on.exit(close(connection), add = TRUE)
writeBin(png, connection, useBytes = TRUE)
