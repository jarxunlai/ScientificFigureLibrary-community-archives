# Nature风格分组DEG条形图

## Purpose
复刻清同趣科研 2026-03-19 文中的 Nature 风格三时间点 DEG 条形图。

## Inputs
- `data/DEGs.csv` — 从微信文章数据表抄录的 23 细胞类型 × 3 时间点计数

## Methods
三列 `geom_rect` 并排；列间距 80，避免 500 与 0 粘连。分组底色按 Intratelencephalic / PT-CT / GABA / Non-neuronal。

## Software and data sources
- R 4.5.3；ggplot2 4.0.3；readr 2.2.0；ragg 1.5.2
- 微信：清同趣科研 2026-03-19。期刊原图来源文章未在微信页给出 DOI，待核。

## Commands and scripts
用户已要求发布。正式条目对应 `drafts/nature-deg-grouped-barplot`。确认前不 Git commit。

```text
pixi run Rscript gallery/nature-deg-grouped-barplot/code/organized.R
```

## Outputs
- `output/figures/nature_deg_grouped_barplot.png`

## Limitations
绘图层复刻。确认前不发布。
