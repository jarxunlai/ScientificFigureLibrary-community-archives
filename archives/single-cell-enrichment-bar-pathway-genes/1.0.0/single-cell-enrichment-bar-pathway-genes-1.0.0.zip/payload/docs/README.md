# Enrichment bar chart with pathway genes

This clean-room example compares four neutral pathways across Cluster A and Cluster B.
The bundled CSV is wholly synthetic. Bar length represents a generic score, while dots and
labels summarize synthetic gene counts and names. It is not derived from a paper, experiment,
patient cohort, website, screenshot, or private reference.

## Re-render

Run the fixed entrypoint with `--input-dir payload/data --output preview.png`.
The renderer uses only base R and writes a deterministic indexed PNG.
